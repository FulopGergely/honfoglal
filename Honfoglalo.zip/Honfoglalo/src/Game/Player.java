package Game;

public class Player {
	
	public void asd() {
		Controller a = new Controller();
		a.setColor(19,1); //ter�let sz�ma, sz�ne.
		//ImageLoad("/kep/r03.png",a[3]);
		
		//a[1] = "asd";
	}

}
